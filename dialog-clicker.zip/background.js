"use strict";
chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === "server-ok") {
        chrome.notifications.create({
            type: "basic",
            iconUrl: "icon.png", // add a 48x48 PNG here
            title: "Auto Dialog Clicker",
            message: "Server responded OK!"
        });
    }
});
