"use strict";
const CONFIG = {
    buttonId: "s_3_1_12_0_Ctrl",
    dialogId: "myDialog",
    fields: {
        value: "s_6_1_47_0",
        periodStart: "s_6_1_48_0",
        periodEnd: "s_6_1_49_0"
    },
    okButtonId: "s_6_1_50_0_Ctrl",
    responseUrl: "/api/submit"
};
// Patch fetch to watch server responses
(function patchFetch() {
    const origFetch = window.fetch;
    window.fetch = async (...args) => {
        const resp = await origFetch(...args);
        const url = typeof args[0] === "string"
            ? args[0]
            : args[0] instanceof Request
                ? args[0].url
                : args[0] instanceof URL
                    ? args[0].toString()
                    : "";
        if (url.includes(CONFIG.responseUrl) && resp.ok) {
            chrome.runtime.sendMessage({ type: "server-ok" });
        }
        return resp;
    };
})();
// Main logic
(async function run() {
    // 1. Click button to open dialog
    document.getElementById(CONFIG.buttonId)?.click();
    // 2. Wait briefly for dialog to appear
    await new Promise((r) => setTimeout(r, 500));
    // 3. Fill fields
    for (const [id, val] of Object.entries(CONFIG.fields)) {
        const el = document.getElementById(id);
        if (el) {
            el.value = val;
            el.dispatchEvent(new Event("input", { bubbles: true }));
        }
    }
    // 4. Click OK
    //document.getElementById(CONFIG.okButtonId)?.click();
})();
